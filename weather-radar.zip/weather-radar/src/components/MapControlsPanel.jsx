import React from 'react';

// MapControlsPanel component receives props to manage radar visibility and open map options
const MapControlsPanel = ({ showRadar, setShowRadar, onAllLayersClick }) => { 
  // Function to toggle radar visibility, passed from App.jsx
  const toggleRadar = () => {
    setShowRadar(prev => !prev);
  };

  // SVG icon for a radar sweep (re-included for completeness)
  const RadarIcon = () => (
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-6 w-6 text-gray-600">
      <path d="M12 2a10 10 0 100 20 10 10 0 000-20z"></path>
      <path d="M12 12L20 12"></path>
      <path d="M12 12L16.94 7.06"></path>
      <path d="M12 12L7.06 16.94"></path>
    </svg>
  );

  return (
    <div className="bg-white rounded-lg shadow-xl p-4 w-72 flex flex-col space-y-4">
      {/* Time Slider Section */}
      <div className="flex flex-col space-y-2">
        <div className="flex items-center justify-between text-sm text-gray-600">
          <span>Sat 7:29p</span>
          <span>Now</span>
        </div>
        <input type="range" min="0" max="100" value="70" className="w-full h-1 bg-gray-200 rounded-lg appearance-none cursor-pointer" />
        <div className="flex justify-between text-xs text-gray-500 mt-1">
          {/* Example time markers */}
          <span>6p</span>
          <span>7p</span>
          <span>8p</span>
          <span>9p</span>
          <span>10p</span>
          <span>11p</span>
          <span>12a</span>
          <span>1a</span>
        </div>
      </div>

      {/* Radar Preview and Layer Buttons */}
      <div className="grid grid-cols-3 gap-2">
        {/* Radar Map Preview */}
        <div className="col-span-1 flex flex-col items-center">
          <div className="w-16 h-16 bg-gray-200 rounded-full flex items-center justify-center overflow-hidden">
            {/* Placeholder for radar map image */}
            <img
              src="https://placehold.co/64x64/E2E8F0/64748B?text=Map"
              alt="Radar Map"
              className="w-full h-full object-cover"
              onError={(e) => { e.target.onerror = null; e.target.src="https://placehold.co/64x64/E2E8F0/64748B?text=Error"; }}
            />
          </div>
          <span className="text-xs text-gray-700 mt-1">Radar Map</span>
        </div>

        {/* 24-Hour Future Radar Button */}
        <button
          onClick={toggleRadar} // This button will toggle the radar layer
          className={`col-span-1 flex flex-col items-center p-2 rounded-lg transition-colors
            ${showRadar ? 'bg-blue-500 text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'}`}
        >
          <div className={`w-10 h-10 rounded-full flex items-center justify-center mb-1
            ${showRadar ? 'bg-blue-600' : 'bg-gray-300'}`}>
            <RadarIcon /> {/* Using the new RadarIcon SVG */}
          </div>
          <span className="text-xs text-center">24-Hour Future Radar</span>
        </button>

        {/* 72-Hour Future Radar Button */}
        <button className="col-span-1 flex flex-col items-center p-2 bg-gray-100 rounded-lg hover:bg-gray-200 transition-colors">
          <div className="w-10 h-10 bg-gray-300 rounded-full flex items-center justify-center mb-1">
            <RadarIcon /> {/* Using the new RadarIcon SVG */}
          </div>
          <span className="text-xs text-center">72-Hour Future Radar</span>
        </button>

        {/* All Layers Button */}
        <button
          onClick={onAllLayersClick} 
          className="col-span-3 flex items-center justify-center p-2 bg-gray-100 rounded-lg hover:bg-gray-200 transition-colors">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2 text-gray-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
          </svg>
          <span className="text-sm font-medium text-gray-700">All Layers</span>
        </button>
      </div>

      {/* Hide Menu / Show Menu Toggle */}
      <div className="text-center mt-4">
        <button className="text-blue-500 text-sm font-medium hover:underline">
          ^ Hide menu
        </button>
      </div>
    </div>
  );
};

export default MapControlsPanel;
