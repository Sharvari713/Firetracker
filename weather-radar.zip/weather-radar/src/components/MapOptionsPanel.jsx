import React, { useState } from 'react';

const MapOptionsPanel = ({ isVisible, onClose }) => {
  const [activeTab, setActiveTab] = useState('layers'); // 'layers' or 'specialty'
  const [mapStyle, setMapStyle] = useState('Light'); // Example state for map style
  const [mainMapLayer, setMainMapLayer] = useState('Feels Like'); // Example state for main map layer
  const [radarAutoplay, setRadarAutoplay] = useState(false); // State for radar autoplay toggle

  if (!isVisible) {
    return null; // Don't render if not visible
  }

  return (
    <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 bg-white rounded-lg shadow-2xl p-6 w-96 max-w-md z-50">
      {/* Close Button */}
      <button
        onClick={onClose}
        className="absolute top-3 right-3 text-gray-400 hover:text-gray-600 p-1 rounded-full bg-gray-100 hover:bg-gray-200 transition-colors"
        aria-label="Close Map Options"
      >
        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
          <path fillRule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clipRule="evenodd" />
        </svg>
      </button>

      {/* Header */}
      <h2 className="text-xl font-bold text-gray-800 mb-4">Map Options</h2>

      {/* Tabs */}
      <div className="flex border-b border-gray-200 mb-4">
        <button
          className={`px-4 py-2 text-sm font-medium ${activeTab === 'layers' ? 'border-b-2 border-blue-600 text-blue-600' : 'text-gray-600 hover:text-gray-800'}`}
          onClick={() => setActiveTab('layers')}
        >
          Layers and Styles
        </button>
        <button
          className={`px-4 py-2 text-sm font-medium ${activeTab === 'specialty' ? 'border-b-2 border-blue-600 text-blue-600' : 'text-gray-600 hover:text-gray-800'}`}
          onClick={() => setActiveTab('specialty')}
        >
          Specialty Maps
        </button>
      </div>

      {/* Content based on active tab */}
      {activeTab === 'layers' && (
        <div className="flex flex-col space-y-4">
          <p className="text-sm text-gray-600">
            Make your map your own. Choose your main map layer, then add on any additional weather
            conditions you want. You can even change the map style and radar speed.
          </p>

          {/* Radar Timeline Autoplay */}
          <div className="flex justify-between items-center py-2 border-b border-gray-200">
            <span className="text-gray-700">Radar Timeline Autoplay</span>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                value=""
                className="sr-only peer"
                checked={radarAutoplay}
                onChange={() => setRadarAutoplay(!radarAutoplay)}
              />
              <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border after:border-gray-300 after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
            </label>
          </div>

          {/* Map Style */}
          <div className="flex justify-between items-center py-2 border-b border-gray-200">
            <span className="text-gray-700">Map Style</span>
            <button className="flex items-center text-blue-600 hover:underline">
              {mapStyle}
              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 ml-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
              </svg>
            </button>
          </div>

          {/* Main map layer */}
          <div className="flex justify-between items-center py-2 border-b border-gray-200">
            <span className="text-gray-700">Main map layer</span>
            <button className="flex items-center text-blue-600 hover:underline">
              {mainMapLayer}
              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 ml-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
              </svg>
            </button>
          </div>

          {/* Add-on layers */}
          <div className="flex justify-between items-center py-2">
            <span className="text-gray-700">Add-on layers</span>
            <button className="flex items-center text-blue-600 hover:underline">
              Location Marker
              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 ml-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
              </svg>
            </button>
          </div>
        </div>
      )}

      {activeTab === 'specialty' && (
        <div className="flex flex-col space-y-4">
          <p className="text-sm text-gray-600">
            Explore various specialty maps for different weather phenomena.
          </p>
          {/* Placeholder for Specialty Maps content */}
          <ul className="list-disc list-inside text-gray-700">
            <li>Temperature Map</li>
            <li>Wind Speed Map</li>
            <li>Cloud Cover Map</li>
            <li>UV Index Map</li>
          </ul>
        </div>
      )}
    </div>
  );
};

export default MapOptionsPanel;
