import React, { useEffect, useRef, useState } from 'react';
import mapboxgl from 'mapbox-gl'; 
import MainMenuHeader from './components/MainMenuHeader';
import MapControlsPanel from './components/MapControlsPanel'; // New component for the bottom-right panel

// Main App component
function App() {
  const mapRef = useRef(null); // Ref to store the Mapbox map instance
  const mapContainerRef = useRef(null); // Ref to the DOM element where the map will be rendered
  const [showRadar, setShowRadar] = useState(true); // State to control radar layer visibility

  useEffect(() => {
    // Ensure map container exists and that the map has not already been initialized for this ref.
    if (mapContainerRef.current && !mapRef.current) {
      // Set your Mapbox access token
      // IMPORTANT: Replace '' with your actual public Mapbox Access Token.
      // If left as an empty string, Canvas will attempt to provide one at runtime.
      mapboxgl.accessToken = 'pk.eyJ1Ijoic2hhcnZhcmlnYWRpd2FuIiwiYSI6ImNtY3F4Y3ZnMzBvZmoybW9ybm5jeTNrbzkifQ.DJ2jQGlbRWRdUtYbTI8jFw'; // Keep this empty for Canvas auto-provisioning or add your token here

      // Initialize the Mapbox map instance
      mapRef.current = new mapboxgl.Map({
        container: mapContainerRef.current, // HTML element to render the map
        style: 'mapbox://styles/mapbox/streets-v11', // A basic Mapbox style
        center: [-98.5795, 39.8283], // Center of US [longitude, latitude]
        zoom: 5, // Initial zoom level
        attributionControl: false // Disable default attribution to add custom ones
      });

      // Add custom attribution control
      mapRef.current.addControl(new mapboxgl.AttributionControl({
        customAttribution: '© OpenStreetMap contributors | Radar © RainViewer'
      }), 'bottom-right');


      // When the map finishes loading, add the radar source and layer
      mapRef.current.on('load', () => {
        // Add RainViewer radar source
        mapRef.current.addSource('radar-tiles', {
          'type': 'raster',
          'tiles': [
            'https://tilecache.rainviewer.com/v2/radar/nowcast/{z}/{x}/{y}/2/1_1.png'
          ],
          'tileSize': 256 // Tile size for the raster tiles
        });

        // Add RainViewer radar layer
        mapRef.current.addLayer({
          'id': 'radar-layer',
          'type': 'raster',
          'source': 'radar-tiles',
          'paint': {
            'raster-opacity': 0.6 // Set opacity for the radar layer
          },
          'layout': {
            'visibility': showRadar ? 'visible' : 'none' // Initial visibility based on state
          }
        });
      });
    }

    // Cleanup function: remove the map instance when the component unmounts
    return () => {
      if (mapRef.current) {
        mapRef.current.remove(); // Remove the map from the DOM and clean up its event listeners
        mapRef.current = null; // Clear the ref
      }
    };
  }, []); 

  // Effect to toggle radar layer visibility when showRadar state changes
  useEffect(() => {
    if (mapRef.current && mapRef.current.isStyleLoaded() && mapRef.current.getLayer('radar-layer')) {
      mapRef.current.setLayoutProperty(
        'radar-layer',
        'visibility',
        showRadar ? 'visible' : 'none'
      );
    }
  }, [showRadar]); // Rerun this effect when showRadar changes


  const handleZoomIn = () => {
    if (mapRef.current) {
      mapRef.current.zoomIn();
    }
  };
  const handleZoomOut = () => {
    if (mapRef.current) {
      mapRef.current.zoomOut();
    }
  };

  const openMapOptions = () => {
    setShowMapOptions(true);
  };

  const closeMapOptions = () => {
    setShowMapOptions(false);
  };

  return (
    // Main application container
    <div className="h-screen w-screen flex flex-col font-inter bg-gray-50">

      <MainMenuHeader />

      <div className="relative flex-1">
        <div
          ref={mapContainerRef}
          className="w-full h-full rounded-lg shadow-lg overflow-hidden"
        >
          {/* Mapbox GL JS map will be injected here */}
        </div>

        {/* Zoom Controls (Left Side) */}
        <div className="absolute top-1/2 left-4 transform -translate-y-1/2 z-20 flex flex-col space-y-2">
          <button
            onClick={handleZoomIn}
            className="bg-white p-2 rounded-full shadow-md hover:bg-gray-100 transition-colors"
            aria-label="Zoom In"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-gray-700" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
            </svg>
          </button>
          <button
            onClick={handleZoomOut}
            className="bg-white p-2 rounded-full shadow-md hover:bg-gray-100 transition-colors"
            aria-label="Zoom Out"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-gray-700" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M18 12H6" />
            </svg>
          </button>
        </div>

        {/* Floating Control Panel (Bottom-Right) */}
        <div className="absolute bottom-4 right-4 z-20">
          <MapControlsPanel
            showRadar={showRadar}
            setShowRadar={setShowRadar}
            onAllLayersClick={openMapOptions}
            // You can pass mapRef here if MapControlsPanel needs direct map interaction
            // map={mapRef.current}
          />
        </div>
      </div>
    </div>
  );
}

export default App;
